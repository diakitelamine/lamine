<?php
/**
 * Created by PhpStorm.
 * User: Administrateur
 * Date: 21/08/2018
 * Time: 11:49
 */

namespace AppBundle\Repository;


use Doctrine\ORM\EntityRepository;

class ArticleRepository extends EntityRepository
{

    public function getAllArticles(){
        $qb = $this->createQueryBuilder('a');

        $qb->select('a.title, a.text, a.createdAt,
         COUNT(c) as numberOfComments')
            ->orderBy('a.createdAt', 'DESC')
        ->innerJoin('AppBundle:Comment', 'c')
        ->groupBy('a.id');

        return $qb->getQuery()->getArrayResult();
    }

    public function getLastArticles($numberOfArticles){
        $qb = $this->createQueryBuilder('a');

        $qb ->select('a')
            ->orderBy('a.createdAt', 'DESC')
            ->setMaxResults($numberOfArticles);

        return $qb->getQuery()->getResult();
    }

    public function getMostPopularArticles($numberOfArticles){
        $qb = $this->createQueryBuilder('a');

        $qb->select('a.id, a.title, COUNT(c) as numberOfComments')
            ->innerJoin('a.comments', 'c')
            ->orderBy('numberOfComments', 'DESC')
            ->groupBy('a.id')
            ->setMaxResults($numberOfArticles);

        return $qb->getQuery()->getArrayResult();

    }

}