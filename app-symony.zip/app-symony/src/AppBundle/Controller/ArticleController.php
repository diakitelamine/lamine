<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use AppBundle\Entity\Comment;
use AppBundle\Form\CommentType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class ArticleController
 * @package AppBundle\Controller
 * @Route("/article")
 */
class ArticleController extends Controller
{
    /**
     * @Route("/list")
     */
    public function indexAction()
    {
        $articles = $this->getDoctrine()
                         ->getRepository('AppBundle:Article')
                         ->findAll();

        $params = $this->getParamsForAside();
        $params['articles'] = $articles;

        return $this->render('Article/index.html.twig', $params);
    }

    private function getParamsForAside(){
        $articleRepository = $this->getDoctrine()
            ->getRepository("AppBundle:Article");

        return [
            'lastArticleList' => $articleRepository->getLastArticles(5),
            'mostPopuplarArticleList' => $articleRepository->getMostPopularArticles(5)
        ];
    }

    /**
     * @Route("/show/{id}")
     */
    public function detailsAction(Article $article, Request $request)
    {
        //Instanciation d'une entité commentaire
        $comment = new Comment();
        //liaison entre le commentaire et l'article
        $comment->setArticle($article);

        //Création du formulaire
        $form = $this->createForm(CommentType::class, $comment);

        //hydratation du formulaire
        $form->handleRequest($request);

        //Traitement du formulaire
        if($form->isSubmitted() and $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($comment);
            $em->flush();

            return $this->redirectToRoute("app_article_details", ["id"=>$article->getId()]);
        }

        return $this->render('Article/details.html.twig', [
            'article'=>$article,
            'commentForm' => $form->createView()
        ]);
    }

}
