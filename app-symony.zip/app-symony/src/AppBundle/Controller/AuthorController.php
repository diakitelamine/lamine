<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use AppBundle\Form\ArticleType;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class AuthorController
 * @package AppBundle\Controller
 * @Route("/author")
 */
class AuthorController extends Controller
{
    public function indexAction($name)
    {
        return $this->render('', array('name' => $name));
    }

    /**
     * @Route("/new-article")
     * @Route("/update-article/{id}", name="article_update")
     */
    public function AddEditArticleAction(Request $request, Article $article = null){

        if($article == null){
            $article = new Article();

            $author = $this->getDoctrine()
                ->getRepository("AppBundle:Author")
                ->findOneByEmail("user1@mail.com");

            $article->setAuthor($author);
        }


        $form = $this->createForm(
            ArticleType::class,
            $article,
            ['attr' =>['novalidate'=>'novalidate']]
        );

        $form->handleRequest($request);

        if($form->isSubmitted() and $form->isValid()){
            $em = $this->getDoctrine()->getManager();
            $em->persist($article);
            $em->flush();

            return $this->redirectToRoute("app_article_index");
        }

        return $this->render("author/article-form.html.twig",
            ['articleForm' => $form->createView()]);
    }
}
