<?php

namespace AppBundle\Controller;

use AppBundle\Entity\Article;
use AppBundle\Entity\Author;
use Faker\Factory;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Routing\Annotation\Route;

/**
 * Class PlaygroundController
 * @package AppBundle\Controller
 * @Route("/play")
 */
class PlaygroundController extends Controller
{

    /**
     * @return \Symfony\Component\HttpFoundation\Response
     * @Route("/new-author/{name}/{firstName}/{email}")
     */
    public function newAuthorAction($name, $firstName, $email){



        //Recherche de l'auteur
        $authorRepository = $this->getDoctrine()
            ->getRepository("AppBundle:Author");

        $authorWithSameEmail = $authorRepository->findOneByEmail($email);

        $author = $authorRepository->findOneBy([
            "email" => $email,
            "name" => $name,
            "firstName" => $firstName
        ]);

        //Création d'un nouvel auteur uniquement s'il n'existe pas déjà
        if(! $authorWithSameEmail and ! $author){
            //Instanciation d'un auteur
            $author = new Author();
            $author ->setName($name)
                ->setFirstName($firstName)
                ->setEmail($email);

            //Récupération de l'entity manager
            $entityManager = $this->getDoctrine()->getManager();

            //persistence des entités
            $entityManager->persist($author);

            //validation de la transaction
            $entityManager->flush();
        }

        return $this->render("playground/new-author.html.twig",
            ["author" => $author]);
    }

    /**
     * @Route("/new-article")
     */
    public function newArticleAction(){
        $faker = Factory::create();

        //Récupération d'un auteur
        $author = $this->getDoctrine()
            ->getRepository("AppBundle:Author")
            ->findOneByName("Hugo");

        //Création de l'entité article
        $article = new Article();
        $article->setAuthor($author)
            ->setText($faker->text(500))
            ->setTitle($faker->jobTitle);

        //Persistence de l'entité article
        $em = $this->getDoctrine()->getManager();
        $em->persist($article);
        $em->flush();

        return $this->render("playground/new-article.html.twig", ["article" => $article]);
    }

}
