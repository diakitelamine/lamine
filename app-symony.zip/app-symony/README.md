{% extends 'layout.html.twig' %}

{% block content %}

    <h1>{{ article.title }}</h1>

    <p>par {{ article.author.firstName }} {{ article.author.name }}</p>
    <p>le {{ article.createdAt | date('d/m/Y') }}</p>

    <p>{{ article.text }}</p>

    <hr>

    <h1>Commentaires</h1>

    {% for item in article.comments %}
        <div>
            <p><strong>par {{ item.email }} le {{ item.createdAt | date('d/m/Y') }}</strong></p>
            <p>{{ item.commentText }}</p>
            <hr>
        </div>
    {% endfor %}

{% endblock %}

{% block title %}

{% endblock %}

