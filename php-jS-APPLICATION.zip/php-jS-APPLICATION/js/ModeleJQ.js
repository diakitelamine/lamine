/* 
 * ModeleJQ.js
 */

function init() {
    initVariablesGlobales();
    initElementsDInterface();
    initEvenements();
} /// init

function initVariablesGlobales() {

} /// initVariablesGlobales

function initElementsDInterface() {

} /// initElementsDInterface

function initEvenements() {

} /// initEvenements

/*
 * MAIN
 */
$(document).ready(init);
